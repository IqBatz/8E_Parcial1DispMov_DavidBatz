import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});
  // sobreescribir la función 
  @override
  Widget build(BuildContext context) {
    // const es que sea constante, si no queremos que lo sea, solo lo removemos
    //return const MaterialApp(
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      //scaffold = estructura
      home: Scaffold(
        backgroundColor: Color.fromARGB(255,65,129,138),
        body: Center( 
          //Theme permite que varíe el tipo de texto en base al tema
          child: Column(
            //cómo alinear los elementos en el eje principal
            //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [

              Text(
                'GUCUMATZ', 
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                     color: Colors.white,
                  ), 
                ),
                Row(
              //mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(width: 31),
                Container(
                  width: 102,
                  height: 60,
                child:Stack(
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                      
                  height: 45,
                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(25), 
                                        color: Color.fromARGB(75, 0, 0, 0),
                                    ), // Primer cuadro al inicio
                ),
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child:Container(
                  height: 60,
                  width: 60,
                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(60), 
                                        color: const  Color(0xFF8CBC70),
                                    ),
                        child: Align(
                          alignment: Alignment.center,
                          child: Text(
                            'E',
                            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                     color: Colors.white,
                  ),
                          ),
                        ),
                ),
                    ),
                
                  ],
                ),
                
                ),
                
                 Spacer(),
                Container(
                  width: 80,
                  height: 54,
                  child: Stack(
                            children: [
                              Positioned(
                                left:0,
                                top:0,
                                child: Container(
                                  width:80,
                                  height: 54,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(25), 
                                    color: const  Color(0xFF8CBC70)
                                    ),
                                  child: const Icon(
                                    Icons.edit,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              /* Container(
                                width:18,
                                height:18,
                                color:Colors.amber
                              ) */
                            ], 
                            
                          ), // Segundo cuadro al final
                ),
                Container(width: 31),
              ],
            ),
              Column(
                children: [
                  Container(
                    height: 107, 
                    width: 107, 
                    decoration: BoxDecoration(
                      //borderRadius: BorderRadius.circular(55), 
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.white,
                        width: 2,
                      ),
                      color: Color.fromARGB(255,44,152,240),
                      
                      ),
                      child: Align(
                        alignment: Alignment.center,
                        child: Text(
                          'A',
                          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                     color: Colors.white,
                  ),
                        ),
                      ),
                  ),
                  Text(
                    'Andrea Ocaña',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                     color: Colors.white,
                     )
                    ),
                ],
              ),
          Row(
            
            children: [
              Container(
                width: 16,
              ),
              Align(alignment: Alignment.bottomLeft,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Align(alignment: Alignment.bottomLeft,
                    child:Text(
                      'Fecha de Nacimiento',
                      style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,
                          ),
                          textAlign: TextAlign.left,
                    )
                    ),
                    Align(alignment: Alignment.bottomLeft,
                    child:Text(
                      '09/04/2003',
                      style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),
                          textAlign: TextAlign.left,
                    )
              ),
              Text('20 años',style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),),
              Row(children: [
                Text(
                  'Nivel Académico',
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),
                          ),
                  Icon(Icons.arrow_drop_down_outlined,
                  color: Colors.white,)
              ],),
              Text('6to semestre en Publicidad con',style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),),
              Text('especialidad en Diseño Gráfico',style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),),
              Text('Universidad Mesoamericana',style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),),
              Text('Campus Quetzaltenango',style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),),
                 Row(children: [
                Text(
                  'Intereses',
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),
                          ),
                  Icon(Icons.arrow_drop_down_outlined,
                  color: Colors.white,)
              ],),
              Text('Fotografía',style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),),
              Text('Radio',style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),),
              Text('Matemáticas',style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),),
              Row(children: [
                Text(
                  'Habilidades',
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),
                          ),
                  Icon(Icons.arrow_drop_down_outlined,
                  color: Colors.white,)
              ],),
              Text('Aprendizaje rápido',style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),),
              Text('Lingüística',style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),),
              Text('Trabaja en Equipo',style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),),
              Text('Fotografía',style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),),
              Text('Radio',style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),),
              Container(height: 12,),
              Text('Categoría: Estudiante',style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,),),
              ],
              ),
              ),
              
            
              
            ],
          ),
             /*  const Carrousel(title: "CURSOS MÁS BUSCADOS"),
              const Carrousel(title: "CURSOS TEÓRICOS"),
              const Carrousel(title: "CURSOS PRÁCTICOS"),
               Container(
                
                height: 80,
                color: Colors
                    .teal[600], 
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children:
                      [
                        Text(
                          'INSERTE PUBLICIDAD NO\n TAN INTRUSIVA', 
                          //style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),// Puedes cambiar el color a tu preferencia
                    
              ),
            */],
          ),
        ),
      ),
    );
  }
}

class Carrousel extends StatelessWidget {
  final title;
  const Carrousel({
    required this.title,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: Text(
          '$title',
          style: Theme.of(context).textTheme.bodyMedium,
          ),
        ),
        SizedBox(
          height: 118, 
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            scrollDirection: Axis.horizontal,
            itemBuilder: ((context, index) => const Card()),
            separatorBuilder: (context, index) => const SizedBox(
              width: 12,
            ),
            itemCount: 4,
          ),
        )
      ],
    );
  }
}

class Card extends StatelessWidget {
  const Card({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 118, 
      width: 239, 
      color: const Color(0xFFDDE3E8),
    );
  }
}
