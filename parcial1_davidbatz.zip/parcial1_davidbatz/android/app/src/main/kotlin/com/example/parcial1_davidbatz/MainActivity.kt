package com.example.parcial1_davidbatz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
